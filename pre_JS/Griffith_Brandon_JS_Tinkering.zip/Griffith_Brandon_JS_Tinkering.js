console.log('hello world ' + "HelloWorld " + 'Hello World');
for (var i = 0; i < 10;) {
    i++
    i++
    console.log('hello friend ' + "good bye friend " + i)
}


function  displayIfChildIsAbleToRideTheRollerCoaster() {
    childHeight = 53
    if (childHeight > 52) {
        console.log("Get on that ride, kiddo!")
    }
    else console.log("Sorry kiddo. Maybe next year.")
}
displayIfChildIsAbleToRideTheRollerCoaster();
console.log('end of program...');
